public class Q19 {
    public static void main(String[] args) {
        int num=7;
        for(int i=num;i>=1;i--){
            for(int j=1;j<=i;j++){
                System.out.print(i );
            }
            System.out.println();//new line
        }
    }
}
