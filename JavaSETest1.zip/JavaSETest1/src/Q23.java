public class Q23 {
    public static void main(String[] args) {
        String[] names = {"KyawGyi","Yewin","KaungKaung","Kyaw Kyaw"};
        for (String name : names) {
            System.out.println(name);
        }
    }
}
