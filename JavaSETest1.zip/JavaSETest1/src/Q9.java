public class Q9 {
    public static void main(String[] args) {
        int number = 4;
        for (int i = 1; i < 5; i++) {
            for (int j = 0; j < 5; j++) {
                System.out.println(j);
            }
        }

    }
}
