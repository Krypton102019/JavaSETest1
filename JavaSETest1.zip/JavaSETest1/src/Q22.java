import java.util.Arrays;

public class Q22 {
    public static void main(String[] args) {
        Integer[] intArray = {1,2,3,4,5,6,7,8,9};
        for(int i=intArray.length-1;i>=0;i--)
            System.out.print(intArray[i] + "  ");
    }
}
