public class Q6 {
    public static void main(String[] args) {
        String days ;
        switch (days = "five"){
            case "one" :
                System.out.println("It is Monday");
                break;
            case "two":
                System.out.println("It is Tuesday");
                break;
            case "three":
                System.out.println("It is Wednesday");
                break;
            case "four":
                System.out.println("It is Thursday");
                break;
            case "five":
                System.out.println("It is Friday");
                break;
            case "six":
                System.out.println("It is Saturday");
                break;
            case "seven":
                System.out.println("It is sunday");
        }
    }
    }

