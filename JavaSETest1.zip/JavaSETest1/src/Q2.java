public class Q2 {
    public static void main(String[] args) {
        int a =5;
        int b =6;
        int temp = 0;
        System.out.println("Before swapping of a is " + a);
        System.out.println("Before swapping of b is " + b);

        temp = a;
        a = b;
        b = temp;


        System.out.println("After swapping of a is " + a);
        System.out.println("After swapping of b is " + b);



    }
}
