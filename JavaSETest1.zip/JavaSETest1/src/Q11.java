import java.util.Arrays;

public class Q11 {

    public static void main(String[] args) {
        int[] intArr = {5, 4, 1, 8, 6, 9};
        int[] arr_new = new int[intArr.length-1];

        System.out.println(Arrays.toString(arr_new));

    }
}
